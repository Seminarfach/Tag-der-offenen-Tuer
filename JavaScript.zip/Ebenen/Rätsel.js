



export const riddleConfig = {
    sudoku: {
        backgroundImage: (() => {
            const img = new Image();
            img.src = './img/Rätsel/RätselHintergrund.jpg';
            return img;
        })(),
        guideImage: (() => {
            const img = new Image();
            img.src = './img/Anleitung/Anleitung Sudoku.png';
            return img;
        })(),
        explanationImage: (() => {
            const img = new Image();
            img.src = './img/Anleitung/ErklärungSudoku.jpg';
            return img;
        })(),
        riddleImage: (() => {
            const img = new Image();
            img.src = './img/Rätsel/RätselHintergrund.jpg'; // Beispielpfad
            return img;
        })(),
        answers: [
            'x:1 | y:3 | z:4',
            'x:2 | y:4 | z:3',
            'x:1 | y:4 | z:3',
            'x:2 | y:4 | z:1',
        ],
        correctAnswer: 'x:1 | y:3 | z:4', // Richtige Antwort als Text
        hints: [
            (() => {
                const img = new Image();
                img.src = './img/Rätsel/Hinweis1.png';
                return img;
            })(),
            (() => {
                const img = new Image();
                img.src = './img/Rätsel/Hinweis2.png';
                return img;
            })(),
            (() => {
                const img = new Image();
                img.src = './img/Rätsel/Lösung.png';
                return img;
            })(),
        ],
        hintTimes: [5, 10, 15], // Aktivierungszeitpunkte für Hinweise
        targetLevel: 'raum1',
    },
};