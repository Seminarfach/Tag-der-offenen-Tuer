
import { riddleConfig } from "./Ebenen/Rätsel.js";
import { levelManager } from "./EbenenModul.js";
import { PDFDocument, rgb } from 'https://cdn.jsdelivr.net/npm/pdf-lib@1.17.1/+esm';



function umsortierenButtons (){

        

        const Antworten = document.getElementById('Answers')
    
        const buttons = Array.from(Antworten.children)

        // Speichere den aktuellen Text jedes Buttons zusammen mit dem Button-Element
        const buttonData = buttons.map((button, index) => ({
            button,
            text: button.textContent, // Speichere den Text
            originalIndex:  parseInt(button.getAttribute('data-index')), // Ursprünglicher Index
        }));
    
        function umsortieren (array) {
    
            for (let i = array.length - 1; i > 0 ; i --) {
                const j = Math.floor(Math.random() * (i + 1));
                [array[i], array[j]] = [array[j], array[i]];
    
            }
    
            return array
        }
    
        const umsortierteButtons = umsortieren(buttonData)

        // Aktualisiere die Buttons im DOM und den Text entsprechend
        umsortierteButtons.forEach(({ button, text, originalIndex }) => {
            button.textContent = text; // Text des Buttons aktualisieren
            button.setAttribute('data-index', originalIndex)
            Antworten.appendChild(button); // Neusortierten Button ins DOM einfügen
        });
        
       // Speichere die neue Reihenfolge der Texte (optional für Debugging oder andere Zwecke)
        const neueReihenfolge = umsortierteButtons.map(({ text }) => text);
        // console.log("Neue Reihenfolge der Button-Texte:", neueReihenfolge);

        
        // console.log("Umsortierte Buttons:", umsortierteButtons.map((b) => ({
        //     text: b.text,
        //     dataIndex: b.originalIndex
        // })));
        
        

    
}   



class RiddleManager {
    constructor(riddleConfig) {
        this.config = riddleConfig; // Konfiguration für alle Rätsel
        this.currentRiddle = null; // Aktuelles Rätsel
        this.hintsPlayed = []; // Status der Hinweise
        this.soundPlayed = [];
        this.isCompleted = false; // Status: Rätsel abgeschlossen
        this.completedRiddles = new Set();

        
    }


    // Initialisiere Eventlistener
    initializeEventListeners() {
        // Hinweis-Buttons
        [1, 2, 3].forEach(index => {
            const button = document.querySelector(`#Hinweis${index}`);
            button.addEventListener('click', () => {
                console.log(`Hinweis-Button ${index} wurde geklickt.`);
                this.hintsPlayed[index - 1] = false;
            });
        });

        // Fortfahren-Button
        document.getElementById('Fortfahren').addEventListener('click', () => {
            audio.ButtonKlick.play()
            if (this.isCompleted) {
                console.log('Rätsel abgeschlossen, Transition zurück in den Raum.');
                const targetLevel = this.config[this.currentRiddle]?.targetLevel
                

                

                

                window.open('https://survey.lamapoll.de/Feedback-ArnoldiCode', '_blank');
                // this.transition({
                //     nextAnimation: () => {
                //         levelManager.startLevel(targetLevel, levelManager.player);
                //     }, // Raum-Animation
                //     onComplete: () => {
                //         //audio.Map.play()
                //         console.log('Spieler zurück im Raum.');
                //     },
                // });
                
            } else {
                document.querySelector('#Content').style.display = "block"
                document.querySelector('#DialogBox').style.display = "none"
                audio.Rätsel.play()
                console.log('Rätsel nicht abgeschlossen.');
                document
                umsortierenButtons()
                startTimer() 
            }
        });

        // Zurück-Button
        document.getElementById('Zurück').addEventListener('click', () => {
            levelManager.shouldAdjustBackground = true
            resetTimer()
            audio.ButtonKlick.play()
            console.log('Zurück gedrückt, Transition zurück.');
            audio.Rätsel.stop()
            const targetLevel = this.config[this.currentRiddle]?.targetLevel
            this.transition({
                nextAnimation: () => {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    levelManager.startLevel(targetLevel, levelManager.player);
                    //console.log(levelManager.shouldAdjustBackground)
                    
                    
                }, // Raum-Animation
                onComplete: () => {
                    console.log('Spieler hat das Rätsel abgebrochen.');
                    //audio.Map.play()
                },
            });
        });

        // Antwort-Buttons
        document.querySelectorAll('.AnswersButton').forEach((button, index) => {
            button.addEventListener('click', () => {
                this.handleAnswer(index);
            });
        });
    }

    // Starte ein Rätsel
    startRiddle(riddleName) {

            levelManager.shouldAdjustBackground = false 

            riddle = true 

            
        
        
            audio.Tuer.play()
            this.transition({


                nextAnimation: () => {

                    document.querySelector('#Interface').style.display = 'block'
                    document.querySelector('#movingInterface').style.display = 'none'
                    document.querySelector('#Content').style.display = 'block'
                    document.querySelector('#GuideBox').style.display = 'none'
                    // document.querySelector('#DialogButton').style.display = 'none'

                    audio.Rätsel.play();
                    startTimer();
                    
                    this.resetRiddle();
                    
                    
                    
            

                    
                    // if(Handy) {
                    //     document.querySelector("#movingInterface").style.display = "none"
                    // }

                    if(!this.config[riddleName]) {
                        console.error(`Rätsel "${riddleName}" exisiert nicht in der Konfirguration.`)
                    }
                    this.currentRiddle = riddleName;
                    const { answers } = this.config[riddleName];

                    this.soundPlayed = false 
                    // Antwort-Buttons aktualisieren
                    const answerButtons = Array.from(document.querySelectorAll('.AnswersButton'));
                    answerButtons.forEach((button, index) => {
                        button.textContent = answers[index] || ''; // Setze Text oder leer, falls nicht vorhanden
                        button.setAttribute('data-index', index); // Ursprünglichen Index speichern
                        console.log(`Button ${index} initialisiert:`, {
                            text: button.textContent,
                            dataIndex: button.getAttribute('data-index')
                        });
                        button.style.display = index < answers.length ? 'block' : 'none'; // Blende ungenutzte Buttons aus
                    });

                    // Hinweise und Status zurücksetzen
                    this.hintsPlayed = new Array(this.config[riddleName].hints.length).fill(true);
                    this.soundPlayed = new Array(this.config[riddleName].hints.length).fill(false);
                    this.isCompleted = false;

                    const interfaceElement = document.querySelector('#Interface');
                    interfaceElement.style.display = 'block';
                    interfaceElement.style.width = `${canvas.width}px`;
                    interfaceElement.style.height = `${canvas.height * 0.3}px`; // 30% der Canvas-Höhe
                    
                    document.querySelector('#IDtimer').style.display = 'flex'

                    // console.log(`Rätsel "${riddleName}" gestartet.`);

                    // console.log("Buttons vor dem Umsortieren:", answerButtons.map((b) => ({
                    //     text: b.textContent,
                    //     dataIndex: b.getAttribute('data-index')
                    // })));
                
                    
                    umsortierenButtons()
                    this.animateRiddle(riddleName)
                },
            
            });
    }

    // Zeichne den Hintergrund
    drawBackground(ctx) {
        if (!this.currentRiddle || !this.config[this.currentRiddle]) {
            console.error('Kein aktives Rätsel oder fehlende Konfiguration.');
            return;
        }


        const { backgroundImage } = this.config[this.currentRiddle];
        const BackgroundWidth = canvas.width;
        const BackgroundHeight = canvas.height;
        const fixedX = canvas.width * 0.5 - BackgroundWidth / 2;
        const fixedY = canvas.height * -0.08;
        //console.log(`Zeichne Rätsel an Position (${fixedX}, ${fixedY}).`);
        ctx.drawImage(backgroundImage, fixedX, fixedY, BackgroundWidth, BackgroundHeight);
        
    }

    // Zeichne Hinweise
    drawHint(ctx, hintIndex) {
        const { hints } = this.config[this.currentRiddle];
        const hintImage = hints[hintIndex];

        if (!hintImage) {
            console.error(`Hinweis-Bild für Index ${hintIndex} nicht gefunden.`);
            return;
        }

        if (!hintImage.complete || hintImage.naturalWidth === 0) {
            console.error(`Hinweis-Bild für Index ${hintIndex} wurde noch nicht geladen.`);
            return;
        }

        const width = canvas.width;
        const height = canvas.height;
        const fixedX = canvas.width * 0.5 - width / 2;
        const fixedY = canvas.height * -0.08;
        //console.log(`Zeichne Hinweis ${hintIndex} an Position (${fixedX}, ${fixedY}).`);
        ctx.drawImage(hintImage, fixedX, fixedY, width, height);
    }

    // Verarbeite Antworten
    handleAnswer(answerIndex) {

        const { correctAnswer } = this.config[this.currentRiddle];
        const answerButtons = Array.from(document.querySelectorAll('.AnswersButton'));
        
        // Finde den Button basierend auf dem ursprünglichen Index
        const selectedButton = answerButtons.find(
            (button) => parseInt(button.getAttribute('data-index')) === answerIndex
        );

        // console.log("Selected Button:", {
        //     index: answerIndex,
        //     buttonText: selectedButton?.textContent,
        //     dataIndex: selectedButton?.getAttribute('data-index')
        // });
        
        const selectedAnswerText = selectedButton?.textContent

        // console.log(correctAnswer)
        // console.log(selectedAnswerText)
        
        audio.Rätsel.stop()
        document.querySelector('#DialogBox').style.display = "grid"
        document.querySelector('#Content').style.display = "none"

        if (selectedAnswerText === correctAnswer) {
            
            // console.log(insgesamteZeit)
            
            // const pdfContainer = document.getElementById('DialogBox')
            // pdfContainer.innerHTML = ''
            // pdfContainer.style.display = "grid"
            // pdfContainer.style.gridRow = "3"
            // pdfContainer.style.justifyContent = "center"

            // const text = document.createElement("div")
            // text.innerHTML = "Urkunde Generator"
            // text.style.display = "flex"
            // text.style.justifyContent = "center"
            // text.style.alignItems = "center"
            // text.style.fontSize = "1.5vw"

            // pdfContainer.appendChild(text)

            
            // const form = document.createElement('form')
            // form.id = 'certificateForm'

            // const nameLabel = document.createElement('label')
            // nameLabel.htmlFor = 'playerName'
            // nameLabel.textContent = 'Dein Name'
            // form.appendChild(nameLabel)

            // const nameInput = document.createElement('input')
            // nameInput.type = 'text'
            // nameInput.id = 'playerName'
            // nameInput.required = true 
            // form.appendChild(nameInput)

            // const submitButton = document.createElement('button')
            // submitButton.type = 'submit'
            // submitButton.style.height = '60%'
            // submitButton.textContent = 'Urkunde erstellen'
            

            

            // pdfContainer.appendChild(form)

            // pdfContainer.appendChild(submitButton)

            // // Formular-Referenz holen

            // // Gemeinsame Funktion für die PDF-Erstellung
            // async function generateCertificate(event) {
            //     event.preventDefault(); // Verhindert das Neuladen der Seite

            //     const nameInput = document.getElementById('playerName');
            //     const playerName = nameInput.value.trim();

            //     if (!playerName) {
            //         alert("Bitte gib deinen Namen ein.");
            //         return;
            //     }

            //     const url = './PDF/Urkunde.pdf';
            //     const existingPdfBytes = await fetch(url).then((res) => res.arrayBuffer());

            //     const pdfDoc = await PDFDocument.load(existingPdfBytes);
            //     const pages = pdfDoc.getPages();
            //     const firstPage = pages[0];

            //     const { width, height } = firstPage.getSize();

            //     firstPage.drawText(playerName, {
            //         x: 350, 
            //         y: height - 200, 
            //         size: 36,
            //         color: rgb(0.8627, 0.5373, 0.1216),
            //     });

            //     firstPage.drawText(`${insgesamteZeit} Sekunden`, {
            //         x: 350,
            //         y: height - 245,
            //         size: 36, 
            //         color: rgb(0.8627, 0.5373, 0.1216),
            //     });

            //     const currentDate = new Date();
            //     const formattedDate = currentDate.toLocaleDateString('de-DE', {
            //         day: '2-digit',
            //         month: '2-digit',
            //         year: 'numeric',
            //     });

            //     firstPage.drawText(` ${formattedDate}`, {
            //         x: 230,
            //         y: height - 520,
            //         size: 20,
            //         color: rgb(0.8627, 0.5373, 0.1216),
            //     });

            //     firstPage.drawText(`${insgesamteZeit}`,{
            //                 x: 500,
            //                 y: height - 300,
            //                 size: 36, 
            //                 color: rgb (0.8627, 0.5373, 0.1216),
            //             })

            //     const pdfBytes = await pdfDoc.save();

            //     const blob = new Blob([pdfBytes], { type: 'application/pdf' });
            //     const link = document.createElement('a');
            //     link.href = URL.createObjectURL(blob);
            //     link.download = `Urkunde-${playerName}.pdf`;
            //     link.click();
            // }

            // // `submit`-Event für Enter und reguläre Formulareinsendung
            // form.addEventListener('submit', generateCertificate);

            // // `click`-Event für den Button
            // submitButton.addEventListener('click', (event) => {
            //     generateCertificate(event);
            // });


            
            
            document.getElementById('Fortfahren').innerText = 'Umfrage';
            console.log('Richtige Antwort ausgewählt.');
            this.isCompleted = true;
            this.completedRiddles.add(this.currentRiddle); // Rätsel als abgeschlossen speichern
            document.querySelector('#DialogText').innerHTML = 'Du hast das Rätsel gelöst!<br>Bitte nimm zum Abschluss an unserer Umfrage teil';
            audio.richtigeAntwort.play();

        } else {
            console.log('Falsche Antwort.');
            document.querySelector('#DialogText').textContent = 'Falsch, bitte versuche es nochmal!';
            audio.falscheAntwort.play();
        }
        stopTimer();
    }

    // Rätsel-Animation starten
    animateRiddle() {
        
        const animate = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Hintergrund und Rätselbild zeichnen
            this.drawBackground(ctx);
            
            //Hinweise zeichnene
            this.hintsPlayed.forEach((played, index) => {
                if (!played) {
                    this.drawHint(ctx, index);
                }
            });

            // Hinweise aktivieren
            const { hintTimes } = this.config[this.currentRiddle];
            
            hintTimes.forEach((time, index) => {
                
                if (insgesamteZeit === time && this.hintsPlayed[index]) {
                    
                    
                    document.querySelector(`#Hinweis${index + 1}`).disabled = false;
                    document.querySelector(`#Hinweis${index + 1}`).style.cursor = "pointer";
                    document.querySelector(`#Hinweis${index + 1}`).style.backgroundColor ='white'
                    
                    if (!this.soundPlayed[index]) {
                        audio.HinweiseErscheinen.play();
                        this.soundPlayed[index] = true; // Markiere den Sound als abgespielt
                        
                    }
                    

                    //this.hintsPlayed[index] = false;
                    
                }
            });

            if (!this.isCompleted) {
                 requestAnimationFrame(animate);
            }
        };

        animate();
    }
    pauseRiddle() {
        // Animation stoppen
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
            console.log("Rätsel-Animation pausiert.");
        }
    
        // Timer stoppen
        stopTimer(); // Implementiert vermutlich die Timer-Logik

        
    }

    resumeRiddle(){
        if (!this.animationId) {
            console.log("Rätsel wird fortgesetzt");
            this.animateRiddle(this.config[this.currentRiddle]);
            
        }
        startTimer()
    }
   

    // Transition verwalten
    transition({ nextAnimation, onComplete }) {
        
        gsap.to('#overlappingDiv', {
            opacity: 1,
            repeat: 3,
            yoyo: true,
            duration: 0.4,
            onComplete: () => {
                gsap.to('#overlappingDiv', {
                    opacity: 1,
                    duration: 0.4,
                    onComplete: () => {
                        if (typeof nextAnimation === 'function') nextAnimation();
                        gsap.to('#overlappingDiv', {
                            opacity: 0,
                            duration: 0.4,
                            onComplete: () => {
                                if (typeof onComplete === 'function') onComplete();
                            },
                        });
                    },
                });
            },
        });
    }
        

    // Reset des Rätsels
    resetRiddle() {
        this.currentRiddle = null;
        this.hintsPlayed = [];
        this.isCompleted = false;
    }

    getIsCompleted() {
        return this.isCompleted;
    }

    showGuide(riddleName) {

    document.querySelector('#Interface').style.display = 'none';
    document.querySelector('#Content').style.display = 'none';
    document.querySelector('#DialogBox').style.display = 'none';
    
        
        
    const { guideImage } = this.config[riddleName];
    const { explanationImage } = this.config[riddleName]

    if (!guideImage) {
        console.error('Keine Anleitung gefunden.');
        this.startRiddle(riddleName); // Starte das Rätsel direkt, falls keine Anleitung vorhanden ist
        return;
    }

    const guide = document.getElementById('guide'); // Der Anleitung-Ordner
    const canvas = document.getElementById('gameCanvas'); // Das Canvas
    guide.style.display = 'grid'; // Anleitung sichtbar machen
    guide.style.gridTemplateRows = '2'
    guide.style.justifyContent ='center'
   

    // Setzen Sie die Größe des Ordners passend zum Canvas
    guide.style.width = `${canvas.width}px`;
    guide.style.height = `${canvas.height}px`;
    guide.style.overflowY = 'auto'
    guide.style.backgroundColor = 'grey'
    

    // Bereinigen Sie den Inhalt des Ordners
    guide.innerHTML = '';

    
   
    
    // Fügen Sie das Bild für die Anleitung hinzu
    const imgElement = document.createElement('img');
    imgElement.src = guideImage.src;
    imgElement.style.maxWidth = '100%'; // Begrenzen Sie die Breite des Bildes
    imgElement.style.height = 'auto';

    const imgSudoku = document.createElement('img')
    imgSudoku.src = explanationImage.src
    imgSudoku.style.maxWidth = '100%'
    imgSudoku.style.height = 'auto'
    


    guide.appendChild(imgElement);

    //Button "Weiter" hinzufügen
    const startButton = document.createElement('button');
    startButton.textContent = 'Weiter';
    startButton.style.cursor = 'pointer';
    startButton.style.width  = '100%';
    startButton.style.height = '200%'
    startButton.style.border =  "black, solid 0.3vw";


    const schließenButton = document.createElement('button')
    schließenButton.textContent = 'Schließen'
    schließenButton.style.cursor = 'pointer'
    schließenButton.style.width = '100%'
    schließenButton.style.height = '200%'
    schließenButton.style.border =  "black, solid 0.3vw";


    
    guide.appendChild(startButton);

    startButton.addEventListener('click', () => {
        audio.ButtonKlick.play()
       

        gsap.to('#overlappingDiv', {
            opacity: 1,
            onComplete: () => {

                guide.innerHTML = ''; // Inhalt des Ordners entfernen
                
                guide.appendChild(imgSudoku)
                guide.appendChild(schließenButton)


                
                
                gsap.to('#overlappingDiv', { opacity: 0 });
            }
        }); 
        

    
    });

    gsap.to('#overlappingDiv', { opacity: 0 });

    

    schließenButton.addEventListener('click', () => {
        audio.ButtonKlick.play()
        guide.innerHTML = ''
        guide.style.display = 'none'
        this.startRiddle('sudoku');

        
    })

   
    

        
    }
}



// Initialisiere den RiddleManager
export const riddleManager = new RiddleManager(riddleConfig);

// Initialisiere Eventlistener
riddleManager.initializeEventListeners();


